#include <iostream>
using namespace std;

int main()
{
    int arr[50], n, i, num;
    int position = -1;

    cout << "How many elements you want to enter? ";
    cin >> n;

    cout << "Enter " << n << " numbers:\n";
    for(i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    cout << "Enter the number you want to search: ";
    cin >> num;

    for(i = 0; i < n; i++)
    {
        if(arr[i] == num)
        {
            position = i + 1;
            break;
        }
    }

    if(position != -1)
        cout << "Number found at position: " << position;
    else
        cout << "Number not found in the array.";

    return 0;
}

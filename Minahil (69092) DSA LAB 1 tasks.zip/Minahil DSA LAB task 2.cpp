#include <iostream>
using namespace std;

int main() {
    int arr[3] = {10, 20, 30};
    int index, newValue;

    cout << "Enter index to update: ";
    cin >> index;

    cout << "Enter new value: ";
    cin >> newValue;

    // Check if index is valid
    if(index >= 0 && index < 3) {
        arr[index] = newValue;
    } else {
        cout << "Invalid index!" << endl;
        return 0;
    }

    cout << "Updated array: ";
    for(int i = 0; i < 3; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
